# Voice output and input

Open Settings → Voice and choose a provider. Off is the default: replies remain text-only and no audio graph is created. Settings save automatically when valid. Windows built-in speech uses installed system voices offline, with no key or server.

OpenAI-compatible endpoint accepts a base URL including `/v1`, a model and a voice. Hosted OpenAI requires a key. Local endpoints can leave the key empty; examples from the specifications are `http://localhost:8880/v1` for Kokoro-FastAPI and `http://localhost:8080/v1` for LocalAI. Kokoro testing was explicitly skipped at the user's request, so compatibility and latency are unverified. Hosted speech has not been live-tested without a user key.

Test Voice plays “Hello. I'm your desktop companion.” and reports time to first audio. Speaking rate, volume, output device, begin-speaking policy and interruption policy apply to replies. The bubble speaker button mutes without changing the provider. Esc cancels synthesis, playback and the pending reply. A missing output device falls back to system default. Speech failures preserve the full text reply and follow the selected failure policy.

Speech processing has a separate copy of the response: code, links, emoji and the speech character limit never shorten the displayed response. Completed synthesized clips are cached under `userData/cache/tts` when enabled, with a 200 MiB LRU cap. Interrupted partial synthesis is not cached. API keys remain encrypted in the main process and are never returned to the renderer. Voice reset clears Voice settings and Voice keys after confirmation.

ElevenLabs requires an encrypted API key and loads voices from the service; an empty selection uses the first available voice. The specified Flash v2.5, Turbo v2.5 and Multilingual v2 models expose stability, similarity boost, style and speaker boost. This provider requests MP3 independently of the OpenAI-compatible format. Its request protocol is tested; live cloud playback is unverified without a user key.

Custom HTTP requires a request URL. POST submits the JSON body template; GET turns its fields into encoded query parameters. The template must contain `{{text}}` and can include `{{voice}}` (the stored voice name) and `{{speed}}`. Text containing quotes/newlines is escaped as JSON data. Use the Headers row editor to reference the encrypted key, for example `Authorization` → `Bearer {{apiKey}}`. A key is optional unless a header references it. The key is never injected into the JSON body.

Choose Raw audio bytes, Base64 string in JSON field, or URL in JSON field, and select the actual audio format. PCM means signed 16-bit little-endian mono at 24 kHz. JSON modes use a field path such as `data.audio` or `data.0.audio`; base64 mode also reads SSE JSON events at that path. URL mode fetches HTTP(S) audio without forwarding request headers or credentials. Redirects, unsafe paths and over-budget responses are rejected. Invalid templates stay visible while the last valid saved settings remain active.

Previously verified on Windows: actual installed-voice enumeration, WinRT synthesis, non-silent Web Audio playback, Esc cancellation, provider-Off audio inactivity and output enumeration with microphone permission denied. Custom HTTP's configurable binary/JSON-base64/JSON-URL and GET modes played PCM through the production renderer in Electron acceptance tests; these are local protocol fixtures, not a claim about every third-party engine. OpenAI-compatible audio transport was covered by HTTP protocol fixtures. Further voice testing is skipped by explicit user instruction. All microphone/STT groundwork is disabled in this release. Mouth animation and lip syncing are deferred to low-priority future features; Test Voice has no mouth preview.

## Optional Kokoro-FastAPI Docker setup (unverified)

The upstream project's [CPU container instructions](https://github.com/remsky/Kokoro-FastAPI#quickest-start-docker-run) use this image. With Docker Desktop running Linux containers:

```powershell
docker run -d --name littlellm-kokoro -p 127.0.0.1:8880:8880 ghcr.io/remsky/kokoro-fastapi-cpu:latest
```

In **Settings → Voice**, select **OpenAI-compatible**, base URL `http://localhost:8880/v1`, model `kokoro`, voice `af_heart`, and no API key. Keep the container running; `docker start littlellm-kokoro` starts it again and `docker stop littlellm-kokoro` stops it. The upstream image can change; pin a reviewed release tag for a reproducible deployment. No container, voice playback or Kokoro test was run during the release review, as requested by the user.

## Voice input — deferred

All voice input/dictation is disabled and deferred by user instruction. Settings shows disabled Off; no microphone preview or recording is active, regardless of stored provider. The following notes describe dormant groundwork for future resumption, not current-release behavior. Read docs/voice-input-handoff.md first.

Open Settings → Voice Input. Off is the default and creates no recorder, microphone request or audio graph. The OpenAI-compatible provider accepts a base URL ending in `/v1`, model and optional encrypted API key. The specification's free offline example is a local Whisper service at `http://localhost:9000/v1`; use the model name required by your service. Hosted services send recordings to the configured hostname. Provider keys stay in main and are not stored in config.json.

The input-bar microphone button toggles recording. Stop releases capture before sending a mono 16 kHz WAV to `/audio/transcriptions`; Cancel or Esc discards the recording/request/countdown. The sprite displays a microphone indicator while capture is open. Recording uses the earlier of the configured maximum and the required 120-second safety watchdog. Toggle mode does not auto-stop on silence; global push-to-talk and hands-free activation remain phase-17 work.

Final transcripts can stay editable, send immediately, or send after a cancellable countdown. Caret insertion, append and replace modes, language, custom vocabulary, spoken punctuation, filler trimming, capitalization and confidence floor use the selected settings. The five most recent transcripts are held only in memory; Last transcript reinserts the latest. Typed drafts remain intact when transcription fails.

Voice Input's live level preview temporarily opens the microphone through the pet only while this panel is visible and focused. It releases on blur, close, provider Off or lease expiry and shows an active-microphone caption. Preview audio is neither buffered nor transcribed. Default and Aggressive noise suppression both request browser suppression; Aggressive additionally gates very quiet frames. Test Microphone explicitly records three seconds, plays them back after releasing capture, then transcribes; Test Connection uploads a short synthetic silent WAV without opening the microphone. Neither action was run during development under the user's waiver.

Audio is bounded in memory, zeroed after use and never written to disk in the current implementation. Developer recording export remains unfinished. Permission denial does not trigger a retry loop; use Open Windows Microphone Settings, enable access, then Retry. Device loss stops the session and selects the system default for the next recording. A capture-release timeout reloads the pet renderer to close capture. Provider Off cancels sessions and pending sends.

Windows dictation, local executable and Custom HTTP STT providers are unavailable until phase 17. Windows dictation has an unresolved offline/package-identity conflict in `docs/DISCREPANCIES.md` entry 33; no alternate backend or packaging change has been made. All voice-input runtime, quality, permission, device, worklet, timing and endpoint checks are skipped/unverified under entry 34. The current implementation has static build/type/lint checks only.
