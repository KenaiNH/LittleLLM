import { z } from 'zod';
export const appErrorSchema = z
  .object({
    code: z.enum([
      'NETWORK_UNREACHABLE',
      'DNS_FAILURE',
      'CONNECTION_REFUSED',
      'TIMEOUT',
      'AUTH_INVALID',
      'AUTH_MISSING',
      'RATE_LIMITED',
      'MODEL_NOT_FOUND',
      'CONTEXT_LENGTH_EXCEEDED',
      'CONTENT_FILTERED',
      'SERVER_ERROR',
      'INVALID_RESPONSE',
      'ABORTED',
      'MIC_PERMISSION_DENIED',
      'MIC_NOT_FOUND',
      'AUDIO_DEVICE_LOST',
      'FILE_TOO_LARGE',
      'FILE_INVALID',
      'UNSUPPORTED_FORMAT',
      'EXECUTABLE_NOT_FOUND',
      'EXECUTABLE_FAILED',
      'UNKNOWN',
    ]),
    userMessage: z.string(),
    detail: z.string().optional(),
    retryable: z.boolean(),
    action: z
      .object({
        label: z.string(),
        kind: z.enum(['open-settings', 'open-url', 'retry', 'open-mic-settings']),
      })
      .optional(),
  })
  .strict();
export type AppError = z.infer<typeof appErrorSchema>;
export function normalizeError(error: unknown): AppError {
  if (error instanceof Error && error.name === 'AbortError')
    return { code: 'ABORTED', userMessage: 'Cancelled', retryable: false };
  return {
    code: 'UNKNOWN',
    userMessage: 'The operation could not be completed.',
    retryable: false,
  };
}
